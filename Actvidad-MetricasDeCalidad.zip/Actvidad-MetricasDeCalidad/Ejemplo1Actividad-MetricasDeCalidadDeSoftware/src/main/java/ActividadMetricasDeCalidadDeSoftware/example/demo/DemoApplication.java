package ActividadMetricasDeCalidadDeSoftware.example.demo;

public class DemoApplication {

	public static void main(String[] args) {
		System.out.println("Hello");
	}

}
