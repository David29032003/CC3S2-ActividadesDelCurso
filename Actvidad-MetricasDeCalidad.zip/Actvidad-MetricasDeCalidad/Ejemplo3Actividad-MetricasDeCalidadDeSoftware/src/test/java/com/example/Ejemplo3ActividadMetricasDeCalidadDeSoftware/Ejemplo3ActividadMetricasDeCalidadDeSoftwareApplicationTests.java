package com.example.Ejemplo3ActividadMetricasDeCalidadDeSoftware;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplo3ActividadMetricasDeCalidadDeSoftwareApplicationTests {

	@Test
	void contextLoads() {
	}

}
