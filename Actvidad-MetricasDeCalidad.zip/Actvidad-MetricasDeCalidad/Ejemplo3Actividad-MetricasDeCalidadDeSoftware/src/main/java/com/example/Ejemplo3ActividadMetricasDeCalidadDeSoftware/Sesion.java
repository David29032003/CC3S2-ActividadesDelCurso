package com.example.Ejemplo3ActividadMetricasDeCalidadDeSoftware;

public class Sesion {
    private String horaInicio;
    private int duracion; // Duración en minutos
    public Sesion(String horaInicio, int duracion) {
        this.horaInicio = horaInicio;
        this.duracion = duracion;
    }
}
