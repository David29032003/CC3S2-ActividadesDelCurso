package com.example.Ejemplo3ActividadMetricasDeCalidadDeSoftware;

public class Ejemplo3ActividadMetricasDeCalidadDeSoftwareApplication {

	public static void main(String[] args) {
		System.out.println("Hello");
	}

}
