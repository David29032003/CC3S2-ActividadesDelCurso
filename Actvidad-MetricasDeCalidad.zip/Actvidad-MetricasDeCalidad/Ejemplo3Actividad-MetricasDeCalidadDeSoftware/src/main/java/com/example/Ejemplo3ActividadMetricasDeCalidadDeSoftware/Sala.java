package com.example.Ejemplo3ActividadMetricasDeCalidadDeSoftware;

public class Sala {
    private int id;
    private int capacidad;
    public Sala(int id, int capacidad) {
        this.id = id;
        this.capacidad = capacidad;
    }
    public int getId() {
        return id;
    }
}
