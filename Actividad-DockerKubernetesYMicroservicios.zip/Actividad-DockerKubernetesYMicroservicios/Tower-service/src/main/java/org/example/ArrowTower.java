package org.example;

public class ArrowTower extends Tower {
    //Constructor de la clase ArrowTower
    //Inicializo una nueva torre de flechas
    public ArrowTower() {
        //Llama al constructor de la clase base Tower con daño 10, alcance 3 y frecuencia de disparo 5
        super(10, 3, 5);
    }
}

