package org.example;

public class LaserTower extends Tower {

    //Constructor de la clase LaserTower
    //Inicializo una nueva torre laser con parametros especificos
    public LaserTower() {
        //Inicializo un nuevo LaserTower con daño 30, alcance 5 y frecuencia de disparo 3
        super(30, 5, 1);
    }
}

