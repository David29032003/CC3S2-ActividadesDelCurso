package org.example;

public class SniperTower extends Tower{
    //Constructor de la clase LaserTower
    //Inicializo una nueva torre francotirador con parametros especificos
    public SniperTower() {
        //Inicializo un nuevo SniperTower con daño 20, alcance 4 y frecuencia de disparo 3
        super(20, 4, 3);
    }
}
