package org.example;

public class CannonTower extends Tower {

    //Constructor de la clase CannonTower
    //Inicializo una nueva torre cañon con parametros especificos
    public CannonTower() {
        //Llama al constructor de la clase base Tower con daño 50, alcance 2 y frecuencia de disparo 3
        super(50, 2, 3);
    }
}

